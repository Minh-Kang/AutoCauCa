# Auto Câu Cá — Android prototype 0.2

Ứng dụng Android độc lập (Kotlin), không yêu cầu root. Dự án được hiệu chỉnh theo video game dọc 1080×2400.

## Logic bản 0.2
- Chụp màn hình bằng MediaProjection; thao tác chạm bằng AccessibilityService.
- Chờ banner báo cá cắn, sau đó chạm nút tròn có móc câu ở dưới.
- Theo dõi mốc đỏ tự di chuyển trên thanh ngang và vùng vàng. Dự đoán vị trí trong khoảng trễ chạm rồi chạm nút móc câu khi mốc sắp/vừa vào vùng yêu cầu.
- Khóa thao tác sau mỗi lần chạm để tránh spam; chỉ cho phép lần tiếp theo khi mốc đỏ di chuyển sang vị trí mới.
- Khi màn hình phần thưởng xuất hiện, không phân biệt cá hay vật phẩm. Chờ nút xanh tiếp tục/nhận thưởng xuất hiện, chạm một lần, rồi tự thả câu tiếp.

## Cài đặt
1. Mở thư mục `AutoCauCa` bằng Android Studio (JDK 17, Android SDK 35).
2. Build > Build APK(s), cài APK lên điện thoại Android.
3. Mở app, bật quyền Trợ năng cho Auto Câu Cá.
4. Cấp quyền chụp màn hình và chuyển sang game.
5. Dừng bằng nút DỪNG AUTO hoặc tắt dịch vụ.

## Lưu ý kiểm thử
Đây vẫn là prototype dựa trên màu sắc và vùng tọa độ quan sát từ video; chưa được chạy/kiểm thử trực tiếp trên máy của bạn. Tỉ lệ UI, hiệu ứng, tốc độ game và độ trễ cảm ứng có thể khác. Nên thử vài lượt khi đang quan sát, không để chạy không giám sát. Nếu game đổi bố cục hoặc màu, cần hiệu chỉnh ROI/ngưỡng màu. Không bảo đảm luôn đạt Hoàn hảo.
