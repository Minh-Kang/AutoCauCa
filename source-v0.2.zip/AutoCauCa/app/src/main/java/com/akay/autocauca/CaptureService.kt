package com.akay.autocauca

import android.app.*
import android.app.Activity
import android.content.pm.ServiceInfo
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder
import android.os.Handler
import android.os.HandlerThread
import android.util.DisplayMetrics
import android.view.WindowManager

/** Vision-driven fishing loop. Screen coordinates are normalized to the captured display. */
class CaptureService : Service() {
    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var display: VirtualDisplay? = null
    private var thread: HandlerThread? = null
    private var handler: Handler? = null

    private enum class State { WAIT_BITE, FIGHT, REWARD }
    private var state = State.WAIT_BITE
    private var lastTapAt = 0L
    private var stateSince = 0L
    private var castSent = false
    private var tapLockedUntilMarkerMoves = false
    private var lastMarkerX = -1f
    private var previousMarkerX = -1f
    private var previousMarkerAt = 0L
    private var missingMeterSince = 0L
    private var stableRewardButtonFrames = 0
    private var ignoreRewardUntilClear = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        createNotification()
        val code = intent?.getIntExtra("resultCode", Activity.RESULT_CANCELED) ?: return START_NOT_STICKY
        @Suppress("DEPRECATION")
        val data = intent.getParcelableExtra<Intent>("data") ?: return START_NOT_STICKY
        val mgr = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mgr.getMediaProjection(code, data)
        projection?.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { stopSelf() }
        }, Handler(mainLooper))

        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(metrics)
        val w = metrics.widthPixels
        val h = metrics.heightPixels
        val dpi = metrics.densityDpi
        thread = HandlerThread("AutoFishingVision").also { it.start() }
        handler = Handler(thread!!.looper)
        reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        reader!!.setOnImageAvailableListener({ r ->
            val image = r.acquireLatestImage() ?: return@setOnImageAvailableListener
            try { analyze(image, w, h) } finally { image.close() }
        }, handler)
        display = projection!!.createVirtualDisplay(
            "AutoFishing", w, h, dpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader!!.surface, null, handler
        )
        stateSince = System.currentTimeMillis()
        return START_NOT_STICKY
    }

    private fun analyze(image: Image, width: Int, height: Int) {
        val now = System.currentTimeMillis()
        if (now - lastTapAt < 65) return
        val plane = image.planes[0]
        val buffer = plane.buffer
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        val bytes = ByteArray(buffer.remaining())
        buffer.get(bytes)
        val padded = Bitmap.createBitmap(rowStride / pixelStride, height, Bitmap.Config.ARGB_8888)
        padded.copyPixelsFromBuffer(java.nio.ByteBuffer.wrap(bytes))
        val frame = Bitmap.createBitmap(padded, 0, 0, width, height)
        padded.recycle()

        val rewardOverlay = isDimmedReward(frame)
        val rewardButton = hasGreenContinueButton(frame)
        val bitePrompt = hasBitePrompt(frame)
        val meter = detectMeter(frame)

        when (state) {
            State.WAIT_BITE -> {
                if (rewardOverlay && !ignoreRewardUntilClear) {
                    switchState(State.REWARD, now)
                } else if (!rewardOverlay) {
                    ignoreRewardUntilClear = false
                    if (bitePrompt) {
                    // The round hook button is the only control used to start the reel-in action.
                    tapButton(.50f, .895f, 75L, now)
                        state = State.FIGHT
                        stateSince = now
                        castSent = true
                        tapLockedUntilMarkerMoves = false
                        lastMarkerX = -1f
                        previousMarkerX = -1f
                    } else if (!castSent && now - stateSince > 900L) {
                        // Start the next cast once after entering the normal fishing screen.
                        tapButton(.50f, .895f, 75L, now)
                        castSent = true
                    }
                }
            }

            State.FIGHT -> {
                if (rewardOverlay) {
                    switchState(State.REWARD, now)
                } else if (meter != null) {
                    missingMeterSince = 0L
                    val x = meter.markerX
                    val inTarget = x >= meter.targetLeft - .008f && x <= meter.targetRight + .008f

                    if (tapLockedUntilMarkerMoves) {
                        if (lastMarkerX >= 0f && kotlin.math.abs(x - lastMarkerX) > .025f) {
                            tapLockedUntilMarkerMoves = false
                        }
                    }

                    if (!tapLockedUntilMarkerMoves) {
                        val dt = if (previousMarkerAt > 0L) (now - previousMarkerAt).coerceAtLeast(1L) else 1L
                        val velocity = if (previousMarkerX >= 0f) (x - previousMarkerX) / dt.toFloat() else 0f
                        // Predict marker position at touch time (roughly 80 ms ahead).
                        val predicted = x + velocity * 80f
                        val movingIntoBand = predicted >= meter.targetLeft && predicted <= meter.targetRight
                        if (inTarget || movingIntoBand) {
                            tapButton(.50f, .895f, 65L, now)
                            tapLockedUntilMarkerMoves = true
                            lastMarkerX = x
                        }
                    }
                    previousMarkerX = x
                    previousMarkerAt = now
                } else {
                    if (missingMeterSince == 0L) missingMeterSince = now
                    if (now - missingMeterSince > 1800L) {
                        switchState(if (rewardOverlay) State.REWARD else State.WAIT_BITE, now)
                        castSent = false
                    }
                }
            }

            State.REWARD -> {
                if (rewardButton) stableRewardButtonFrames++ else stableRewardButtonFrames = 0
                // Reward pages can animate for several seconds. Tap only after the green CTA is stable.
                if (stableRewardButtonFrames >= 3 && now - stateSince > 500L) {
                    tapButton(.50f, .963f, 80L, now)
                    switchState(State.WAIT_BITE, now)
                    castSent = false
                    ignoreRewardUntilClear = true
                    stableRewardButtonFrames = 0
                }
            }
        }
        frame.recycle()
    }

    private data class Meter(val markerX: Float, val targetLeft: Float, val targetRight: Float)

    /** Locate the moving red marker and yellow target segment on the horizontal meter. */
    private fun detectMeter(b: Bitmap): Meter? {
        val left = (b.width * .20f).toInt()
        val right = (b.width * .80f).toInt()
        val top = (b.height * .735f).toInt()
        val bottom = (b.height * .805f).toInt()
        val stepX = (b.width / 540).coerceAtLeast(1)
        val stepY = (b.height / 900).coerceAtLeast(1)
        val redByColumn = IntArray(b.width)
        val goldByColumn = IntArray(b.width)
        for (y in top until bottom step stepY) {
            for (x in left until right step stepX) {
                val c = b.getPixel(x, y)
                val r = (c ushr 16) and 255
                val g = (c ushr 8) and 255
                val bl = c and 255
                if (r > 145 && r > g * 1.28 && r > bl * 1.20 && g < 175) redByColumn[x]++
                if (r > 175 && g > 125 && bl < 145 && r > g * 1.05) goldByColumn[x]++
            }
        }
        // Ignore red decoration at the extreme edges; the marker sits on the meter track.
        var redSum = 0L
        var redCount = 0
        for (x in (b.width * .27f).toInt() until (b.width * .76f).toInt()) {
            if (redByColumn[x] >= 2) { redSum += x.toLong() * redByColumn[x]; redCount += redByColumn[x] }
        }
        if (redCount < 7) return null

        val goldCols = ArrayList<Int>()
        for (x in (b.width * .24f).toInt() until (b.width * .78f).toInt()) {
            if (goldByColumn[x] >= 2) goldCols.add(x)
        }
        if (goldCols.size < b.width * .035f) return null
        // Use the longest contiguous yellow run, not isolated sparkle pixels.
        var bestStart = -1; var bestEnd = -1; var runStart = goldCols[0]; var prev = goldCols[0]
        for (i in 1 until goldCols.size) {
            val x = goldCols[i]
            if (x - prev > stepX * 3) {
                if (prev - runStart > bestEnd - bestStart) { bestStart = runStart; bestEnd = prev }
                runStart = x
            }
            prev = x
        }
        if (prev - runStart > bestEnd - bestStart) { bestStart = runStart; bestEnd = prev }
        if (bestStart < 0 || bestEnd <= bestStart) return null
        return Meter(
            redSum.toFloat() / redCount / b.width,
            bestStart.toFloat() / b.width,
            bestEnd.toFloat() / b.width
        )
    }

    private fun hasBitePrompt(b: Bitmap): Boolean {
        // Purple warning banner above the round hook control; ignore the button itself.
        val x1 = (b.width * .34f).toInt(); val x2 = (b.width * .76f).toInt()
        val y1 = (b.height * .815f).toInt(); val y2 = (b.height * .875f).toInt()
        var hits = 0; var samples = 0
        val sx = (b.width / 240).coerceAtLeast(1); val sy = (b.height / 480).coerceAtLeast(1)
        for (y in y1 until y2 step sy) for (x in x1 until x2 step sx) {
            val c = b.getPixel(x, y); val r=(c ushr 16) and 255; val g=(c ushr 8) and 255; val bl=c and 255
            samples++
            if (r > 105 && bl > 115 && bl > g * 1.12 && r > g * 1.08) hits++
        }
        return samples > 0 && hits.toFloat() / samples > .075f
    }

    private fun isDimmedReward(b: Bitmap): Boolean {
        // Reward popups dim the fishing scene. Require a yellow/gold reward heading as well.
        val x1=(b.width*.12f).toInt(); val x2=(b.width*.88f).toInt()
        val y1=(b.height*.22f).toInt(); val y2=(b.height*.78f).toInt()
        var sum=0L; var n=0; var yellow=0
        val sx=(b.width/100).coerceAtLeast(1); val sy=(b.height/180).coerceAtLeast(1)
        for(y in y1 until y2 step sy) for(x in x1 until x2 step sx) {
            val c=b.getPixel(x,y); val r=(c ushr 16) and 255; val g=(c ushr 8) and 255; val bl=c and 255
            sum += (r+g+bl)/3; n++
            if(r>175 && g>125 && bl<105 && r>g*1.08) yellow++
        }
        return n>0 && sum.toFloat()/n < 105f && yellow > 18
    }

    private fun hasGreenContinueButton(b: Bitmap): Boolean {
        val x1=(b.width*.30f).toInt(); val x2=(b.width*.70f).toInt()
        val y1=(b.height*.925f).toInt(); val y2=(b.height*.985f).toInt()
        var hits=0; var samples=0
        val sx=(b.width/240).coerceAtLeast(1); val sy=(b.height/480).coerceAtLeast(1)
        for(y in y1 until y2 step sy) for(x in x1 until x2 step sx) {
            val c=b.getPixel(x,y); val r=(c ushr 16) and 255; val g=(c ushr 8) and 255; val bl=c and 255
            samples++
            if(g>135 && g>r*1.22 && g>bl*1.12) hits++
        }
        return samples>0 && hits.toFloat()/samples > .035f
    }

    private fun tapButton(x: Float, y: Float, hold: Long, now: Long) {
        val dm=DisplayMetrics()
        @Suppress("DEPRECATION")
        (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(dm)
        TapAccessibilityService.instance?.touch(dm.widthPixels*x, dm.heightPixels*y, hold)
        lastTapAt=now
    }

    private fun switchState(next: State, now: Long) {
        state=next; stateSince=now; missingMeterSince=0L
        previousMarkerX=-1f; previousMarkerAt=0L; lastMarkerX=-1f
        tapLockedUntilMarkerMoves=false; stableRewardButtonFrames=0
    }

    private fun createNotification() {
        val channel="autocauca"
        if(Build.VERSION.SDK_INT>=26) {
            val nm=getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel(channel,"Auto Câu Cá",NotificationManager.IMPORTANCE_LOW))
        }
        val n=if(Build.VERSION.SDK_INT>=26) Notification.Builder(this,channel) else Notification.Builder(this)
        val notification=n.setContentTitle("Auto Câu Cá đang chạy")
            .setContentText("Đang nhận diện và điều khiển màn hình game")
            .setSmallIcon(android.R.drawable.ic_media_play).build()
        if(Build.VERSION.SDK_INT>=29) startForeground(8,notification,ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else startForeground(8,notification)
    }

    override fun onDestroy() {
        display?.release(); reader?.close(); projection?.stop(); thread?.quitSafely(); super.onDestroy()
    }
}
