package com.akay.autocauca

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val requestCapture = 701
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(36, 48, 36, 24); gravity = Gravity.CENTER }
        box.addView(TextView(this).apply { text = "AUTO CÂU CÁ · BẢN THỬ NGHIỆM\n\n1. Bật quyền Trợ năng.\n2. Cấp quyền chụp màn hình.\n3. Mở game và nhấn BẮT ĐẦU."; textSize = 18f })
        fun btn(label: String, action: () -> Unit) { box.addView(Button(this).apply { text = label; setOnClickListener { action() } }) }
        btn("1 · BẬT QUYỀN TRỢ NĂNG") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        btn("2 · CẤP QUYỀN CHỤP MÀN HÌNH & BẮT ĐẦU") {
            val mgr = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            startActivityForResult(mgr.createScreenCaptureIntent(), requestCapture)
        }
        btn("DỪNG AUTO") { stopService(Intent(this, CaptureService::class.java)); Toast.makeText(this, "Đã gửi lệnh dừng", Toast.LENGTH_SHORT).show() }
        setContentView(box)
    }
    @Deprecated("Deprecated in Android API; retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == requestCapture && resultCode == RESULT_OK && data != null) {
            val i = Intent(this, CaptureService::class.java).putExtra("resultCode", resultCode).putExtra("data", data)
            startForegroundService(i)
            Toast.makeText(this, "Đã bật nhận diện. Chuyển sang game.", Toast.LENGTH_LONG).show()
        }
    }
}
