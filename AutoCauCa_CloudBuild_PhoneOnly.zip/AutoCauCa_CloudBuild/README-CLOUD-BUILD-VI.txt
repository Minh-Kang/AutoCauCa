BUILD APK BANG DIEN THOAI (KHONG CAN MAY TINH)

Goi nay chua:
- source-v0.2.zip: ma nguon Android
- .github/workflows/build-apk.yml: quy trinh build APK tren may chu GitHub

CACH LAM:
1. Tren dien thoai, mo https://github.com va dang nhap/tao tai khoan.
2. Tao repository moi, dat ten AutoCauCa, chon Public hoac Private, tao repository.
3. Trong repository, chon Add file > Upload files.
4. Tai len ca 2 muc: file source-v0.2.zip va thu muc .github/workflows/build-apk.yml (can giu dung cau truc thu muc). Neu giao dien dien thoai khong cho tai len thu muc an .github, mo GitHub bang Chrome > menu > Trang web cho may tinh.
5. Commit changes.
6. Mo tab Actions > Build AutoCauCa APK > Run workflow > Run workflow.
7. Cho workflow chay xong (mau xanh). Mo run vua chay, keo xuong Artifacts, tai AutoCauCa-debug-apk.zip.
8. Mo ZIP vua tai, giai nen, bam app-debug.apk de cai dat. Neu Android hoi, cho phep Chrome/Files cai ung dung khong ro nguon.

LUU Y:
- Can internet va tai khoan GitHub; thao tac tren dien thoai duoc.
- Neu build that bai, vao Actions > run bi do > mo log va gui anh/log loi de sua.
- APK debug chua duoc ky phat hanh. Chi cai tren may cua ban va khong chia se.
- Day la prototype chua duoc kiem thu tren game/may cua ban; khong dam bao auto chinh xac.
